/*
 * Copyright (c) Lightstreamer Srl
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.*;
import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lightstreamer.interfaces.data.*;

public class HelloWorldDataAdapter implements SmartDataProvider {

    private ItemEventListener listener;
    private volatile GreetingsThread gt;

    public void init(Map params, File configDir) throws DataProviderException {
    }

    public boolean isSnapshotAvailable(String itemName) throws SubscriptionException {
        return false;
    }

    public void setListener(ItemEventListener listener) {
        this.listener = listener;
    }

    public void subscribe(String itemName, Object itemHandle, boolean needsIterator)
            throws SubscriptionException, FailureException {
        if (itemName.equals("greetings")) {
            gt = new GreetingsThread(itemHandle);
            gt.start();
        }
    }
    
    public void subscribe(String itemName, boolean needsIterator)
                throws SubscriptionException, FailureException {
    }         	

    public void unsubscribe(String itemName) throws SubscriptionException,
            FailureException {
        if (itemName.equals("greetings") && gt != null) {
            gt.go = false;
        }
    }

    class GreetingsThread extends Thread {

        private final Object itemHandle;
        public volatile boolean go = true;

        public GreetingsThread(Object itemHandle) {
            this.itemHandle = itemHandle;
        }

        public void run() {
		        int c = 0;
    		    Random rand = new Random();
            while(go) {
	        	 ObjectMapper mapper = new ObjectMapper();
	             Person sandeep = new Person();
	             sandeep.name = (c % 2 == 0 )? "Nagarjun" : "Sandeep";
	             sandeep.age = 27;
	             sandeep.location = "USA";
	             String jsonString = "";
	             try{
	            	 jsonString = mapper.writeValueAsString(sandeep);
	            	 System.out.println("HelloWorldDataAdapter.main() --> "+jsonString);
	            }catch(Exception ex){
	            	System.out.println("HelloWorldDataAdapter.main()");
	            }
	           
                Map<String, String> data = new HashMap<String, String>();
                data.put("message", jsonString);
                data.put("timestamp", new Date().toString());
                listener.smartUpdate(itemHandle, data, false);
                c++;
                try {
                    Thread.sleep(1000 + rand.nextInt(2000));
                } catch (InterruptedException e) {
                }
            }
        }
    }

    
    
    public static  void main(String[] args){
        System.out.println("hello world");
        ObjectMapper mapper = new ObjectMapper();
        Person sandeep = new Person();
        sandeep.name = "sandeep";
        sandeep.age = 27;
        sandeep.location = "USA";
        
        try{
        	 String jsonString = mapper.writeValueAsString(sandeep);
        	 System.out.println("HelloWorldDataAdapter.main() --> "+jsonString);
        }catch(Exception ex){
        	System.out.println("HelloWorldDataAdapter.main()");
        }
       
        
    }

}

class Person {
	public String name;
	public int age;
	public String location;
}